
import discord
from discord.ext import commands

# Replace with your bot's token
TOKEN = 'YOUR_BOT_TOKEN'

# Create bot with a prefix for commands
bot = commands.Bot(command_prefix='!')

# Event: Bot is ready
@bot.event
async def on_ready():
    print(f'{bot.user} has connected to Discord!')

# Command: Responds to a greeting
@bot.command(name='hello')
async def greet(ctx):
    await ctx.send(f'Hello, {ctx.author.name}!')

# Run the bot
bot.run(TOKEN)
